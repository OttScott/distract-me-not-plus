/**
 * Distract-Me-Not Chrome Service Worker
 * This service worker uses importScripts to load required libraries
 */

/**
 * Distract-Me-Not Service Worker
 * 
 * This service worker provides URL blocking functionality through three main mechanisms:
 * 1. webNavigation API - Captures address bar navigations
 * 2. tabs.onUpdated - Captures page loads and in-page navigations
 * 3. (When available) webRequest API - Extra coverage for link clicks
 * 
 * URLs are matched against deny list/allow list patterns using regex-converted wildcards.
 * URLs that should be blocked are redirected to a blocking page.
 */

// Import sync logging utility - this comment will be removed in Chrome builds
// @ts-ignore
importScripts('service-worker-sync-logging.js');

// Try to load required libraries - this will be replaced with inlined code in Chrome builds
try {
  importScripts('browser-polyfill.min.js');
  importScripts('bcrypt.min.js');
  console.log('Successfully imported browser-polyfill and bcrypt libraries');
} catch (e) {
  console.error('Failed to import libraries:', e);
  console.log('This is normal for Chrome builds where the libraries are inlined');
}

// Block attempts to load analytics and tracking scripts
if (typeof browser !== 'undefined' && browser.webRequest) {
  browser.webRequest.onBeforeRequest.addListener(
    (details) => {
      console.log('Blocked external script:', details.url);
      return { cancel: true };
    },
    { 
      urls: [
        "*://www.googletagmanager.com/*",
        "*://googletagmanager.com/*",
        "*://www.google-analytics.com/*",
        "*://ssl.google-analytics.com/*",
        "*://tagmanager.google.com/*",
        "*://analytics.google.com/*"
      ],
      types: ["script", "xmlhttprequest"] 
    },
    ["blocking"]
  );
  console.log('Analytics and tag manager blocking enabled');
}

// Enhanced service worker with core blocking functionality

console.log('Enhanced service worker starting...');

// Define the wildcardToRegExp function needed for URL pattern matching
function wildcardToRegExp(pattern) {
  // First, normalize pattern to lowercase for case-insensitive matching
  // We'll still use the 'i' flag, but this helps with pre-processing
  pattern = pattern.toLowerCase().trim();
  
  // Detect if this is likely a domain-only pattern (no protocol, no path)
  const isDomainOnly = !pattern.includes('://') && !pattern.includes('/');
  
  // Handle domain-only patterns specially
  if (isDomainOnly) {
    // First, escape any regex special characters
    const escaped = pattern.replace(/[-\/\\^$+?.()|[\]{}]/g, '\\$&');
    
    // Replace wildcards with appropriate regex
    const regexPattern = escaped.replace(/\*/g, '.*');
    
    // Special case for *.domain.com to match both domain.com and subdomains
    if (pattern.startsWith('*.')) {
      const domainPart = escaped.substring(2); // Remove *. prefix
      return new RegExp(`(^|\\.)${domainPart}$`, 'i');
    }
    
    // For domain-only patterns, make the regex match either the full domain
    // or as a subdomain suffix (e.g., "example.com" matches "example.com" and "sub.example.com")
    return new RegExp(`(^|\\.)${regexPattern}$`, 'i');
  }
  
  // For patterns with a specified path or protocol, do standard wildcard conversion
  const escaped = pattern.replace(/[-\/\\^$+?.()|[\]{}]/g, '\\$&');
  const regexPattern = escaped.replace(/\*/g, '.*');
  return new RegExp(`^${regexPattern}$`, 'i');
}

// Import necessary constants for the basic functionality
const defaultTimerRuntime = {
  duration: 0,
  endDate: 0,
  remainingDuration: 0
};

const defaultTimerSettings = {
  isEnabled: false,
  defaultValue: '00:30',
  allowStoppingTimer: true,
  allowUsingTimerWithoutPassword: true,
  displayNotificationOnComplete: true,
  runtime: defaultTimerRuntime
};

// Add default framesType definition
const defaultFramesType = ['main_frame'];
const defaultMode = 'combined'; // Use 'combined' mode to match UI default
const defaultIsEnabled = false;

// Basic state
let isEnabled = defaultIsEnabled;
let mode = defaultMode;
let blacklist = []; // denylist (legacy name kept for backward compatibility)
let whitelist = []; // allowlist (legacy name kept for backward compatibility)
let blacklistKeywords = []; // denylist keywords
let whitelistKeywords = []; // allowlist keywords
let timerSettings = defaultTimerSettings;
let framesType = defaultFramesType;

// Constants for declarativeNetRequest
const MAX_RULES = 5000; // Chrome has a limit of 5000 dynamic rules
const BASE_RULE_ID = 1000; // Starting rule ID
let currentRules = [];

// Enhanced logging functionality
function logInfo(message, data) {
  console.log(`[DMN INFO] ${message}`, data || '');
}

function logWarning(message, data) {
  console.warn(`[DMN WARNING] ${message}`, data || '');
}

function logError(message, error) {
  console.error(`[DMN ERROR] ${message}`, error || '');
}

// Flag to track whether we're in a fresh install/initialization
let isInitialInstall = true;

// Helper to check if rules seem to have come from default initialization
function isLikelyFreshInstall() {
  // Check if we have any user-defined rules yet
  const hasNoRules = 
    blacklist.length === 0 && 
    whitelist.length === 0 &&
    blacklistKeywords.length === 0 &&
    whitelistKeywords.length === 0;
  
  // Only true for first run after installation
  return isInitialInstall && hasNoRules;
}

/**
 * Force pull the latest data from sync storage and update local storage and memory
 * This is especially important for fresh installs
 */
async function forcePullFromSyncStorage() {
  try {
    logInfo('Force-pulling data from sync storage');
    
    // Extra diagnostics if available
    if (typeof self.diagnoseSyncStatus === 'function') {
      await self.diagnoseSyncStatus();
    }
    
    // Define all the sync settings we want to check
    const syncSettings = {
      blacklist: [],
      whitelist: [],
      blacklistKeywords: [],
      whitelistKeywords: [],
      mode: defaultMode,
      framesType: defaultFramesType,
      message: '', 
      redirectUrl: '',
      schedule: { isEnabled: false, days: {} }
    };
    
    // Get sync data - use getBytesInUse first to check if there's any data
    let bytesInUse = 0;
    try {
      bytesInUse = await new Promise((resolve) => {
        chrome.storage.sync.getBytesInUse(null, (bytes) => {
          resolve(bytes || 0);
        });
      });
      
      logInfo(`Sync storage contains ${bytesInUse} bytes of data`);
    } catch (bytesError) {
      logError('Error checking sync storage size:', bytesError);
    }
    
    logInfo('Requesting data from sync storage...');
    const syncData = await chrome.storage.sync.get(syncSettings);
    
    // Validate sync data
    const hasValidRules = 
      (Array.isArray(syncData.blacklist) && syncData.blacklist.length > 0) || 
      (Array.isArray(syncData.whitelist) && syncData.whitelist.length > 0);
    
    logInfo(`Sync data received - blacklist: ${syncData.blacklist?.length || 0}, whitelist: ${syncData.whitelist?.length || 0}`);
    
    // If we have valid rules in sync, overwrite local data
    if (hasValidRules) {
      logInfo('Valid rules found in sync storage, updating local data');
      
      // Create safe versions of the data with defaults
      const safeData = {
        blacklist: Array.isArray(syncData.blacklist) ? syncData.blacklist : [],
        whitelist: Array.isArray(syncData.whitelist) ? syncData.whitelist : [],
        blacklistKeywords: Array.isArray(syncData.blacklistKeywords) ? syncData.blacklistKeywords : [],
        whitelistKeywords: Array.isArray(syncData.whitelistKeywords) ? syncData.whitelistKeywords : [],
        mode: syncData.mode || defaultMode,
        framesType: syncData.framesType || defaultFramesType
      };
      
      // Update local storage
      await chrome.storage.local.set(safeData);
      
      // Update in-memory variables
      blacklist = safeData.blacklist;
      whitelist = safeData.whitelist;
      blacklistKeywords = safeData.blacklistKeywords;
      whitelistKeywords = safeData.whitelistKeywords;
      mode = safeData.mode;
      framesType = safeData.framesType;
      
      // Update rules and clear cache
      setupBlockingRules();
      blockedUrls.clear();
      
      // Check all tabs with the new rules
      if (isEnabled) {
        checkAllTabs();
      }
      
      // Log success
      logInfo('Successfully updated local storage and memory with sync data');
      return true;
    } else {
      // Troubleshooting info
      if (bytesInUse > 0 && !hasValidRules) {
        logWarning('SYNC ANOMALY: Sync storage reports data exists, but no valid rules were returned');
        
        // Try a more explicit request for blacklist and whitelist directly
        try {
          const directSyncData = await chrome.storage.sync.get(['blacklist', 'whitelist']);
          logInfo('Direct sync query results:', {
            hasBlacklist: !!directSyncData.blacklist,
            blacklistLength: Array.isArray(directSyncData.blacklist) ? directSyncData.blacklist.length : 'not array',
            hasWhitelist: !!directSyncData.whitelist,
            whitelistLength: Array.isArray(directSyncData.whitelist) ? directSyncData.whitelist.length : 'not array'
          });
        } catch (directError) {
          logError('Error in direct sync query:', directError);
        }
      } else {
        logInfo('No valid rules found in sync storage, keeping current data');
      }
      return false;
    }
  } catch (error) {
    logError('Error force-pulling from sync storage:', error);
    return false;
  }
}

async function init() {
  try {
    logInfo('Initializing service worker...');
    // Settings that should sync between devices
    // Use "blacklist"/"whitelist" for backwards compatibility,
    // but refer to them in the UI/logs as deny list/allow list
    const syncSettings = {
      blacklist: [], // deny list
      whitelist: [], // allow list
      blacklistKeywords: [], // deny list keywords  
      whitelistKeywords: [], // allow list keywords
      mode: mode,
      framesType: defaultFramesType,
      message: '', 
      redirectUrl: '',
      schedule: { isEnabled: false, days: {} }
    };
    
    // Settings that should remain local to this device
    const localSettings = {
      isEnabled: isEnabled,
      password: {},
      timer: defaultTimerSettings,
      enableLogs: false,
      logsLength: 100
    };
    
    // Try to get synced settings first
    try {
      // Log that we're attempting to read from sync storage
      if (typeof self.syncDebug !== 'undefined') {
        self.syncDebug.log('Initializing service worker: Attempting to read from sync storage', {
          keys: Object.keys(syncSettings)
        });
      }
      
      // Ensure syncSettings has default values for all keys
      const fullSyncSettings = {
        blacklist: [],
        whitelist: [],
        blacklistKeywords: [],
        whitelistKeywords: [],
        mode: defaultMode,
        framesType: defaultFramesType,
        message: '', 
        redirectUrl: '',
        schedule: { isEnabled: false, days: {} },
        ...syncSettings // Merge with any provided settings
      };
      
      // IMPORTANT: NEVER WRITE TO SYNC DURING INITIAL INSTALLATION
      // Just read from sync, never write during init on a fresh install
      let items = await chrome.storage.sync.get(fullSyncSettings);
      
      // Create a safe result object with defaults for all expected values
      const safeItems = {
        // Default values
        blacklist: [], // deny list
        whitelist: [], // allow list  
        blacklistKeywords: [], // deny list keywords
        whitelistKeywords: [], // allow list keywords
        mode: defaultMode,
        framesType: defaultFramesType,
        message: '',
        redirectUrl: '',
        schedule: { isEnabled: false, days: {} },
        
        // Override with any valid values from items
        ...items
      };
      
      // Ensure we have valid arrays for lists
      safeItems.blacklist = Array.isArray(safeItems.blacklist) ? safeItems.blacklist : [];
      safeItems.whitelist = Array.isArray(safeItems.whitelist) ? safeItems.whitelist : [];
      safeItems.blacklistKeywords = Array.isArray(safeItems.blacklistKeywords) ? safeItems.blacklistKeywords : [];
      safeItems.whitelistKeywords = Array.isArray(safeItems.whitelistKeywords) ? safeItems.whitelistKeywords : [];
      
      // Replace items with our safe object
      items = safeItems;
      
      logInfo('Successfully retrieved sync settings', items);
      
      // Log the retrieved settings
      if (typeof self.syncDebug !== 'undefined') {
        self.syncDebug.log('Successfully loaded settings from sync storage', {
          keys: items ? Object.keys(items) : [],
          denyListCount: items.blacklist ? items.blacklist.length : 0,
          allowListCount: items.whitelist ? items.whitelist.length : 0,
          denyListKeywordsCount: items.blacklistKeywords ? items.blacklistKeywords.length : 0,
          allowListKeywordsCount: items.whitelistKeywords ? items.whitelistKeywords.length : 0
        });
      }
      
      // Update local state with synced values
      blacklist = items.blacklist || [];
      whitelist = items.whitelist || [];
      blacklistKeywords = items.blacklistKeywords || [];
      whitelistKeywords = items.whitelistKeywords || [];
      mode = items.mode || defaultMode;
      framesType = items.framesType || defaultFramesType;
      
      // IMPORTANT: For a fresh install, ALWAYS save sync data to local storage
      // This ensures we have rules locally even if writing to sync fails later
      if (isInitialInstall || blacklist.length > 0 || whitelist.length > 0) {
        logInfo('Saving sync settings to local storage (for data preservation)');
        await chrome.storage.local.set({
          blacklist: blacklist,
          whitelist: whitelist,
          blacklistKeywords: blacklistKeywords,
          whitelistKeywords: whitelistKeywords,
          mode: mode,
          framesType: framesType
        });
      }
    } catch (error) {
      logError('Error retrieving from sync storage, falling back to local:', error);
      
      if (typeof self.syncDebug !== 'undefined') {
        self.syncDebug.error('Failed to load settings from sync storage', error);
      }
      
      // Fall back to local storage for sync settings
      try {
        if (typeof self.syncDebug !== 'undefined') {
          self.syncDebug.log('Falling back to local storage for sync settings');
        }
        
        const localItems = await chrome.storage.local.get(syncSettings);
        logInfo('Retrieved sync settings from local storage fallback', localItems);
        
        // Update state with local fallback values
        blacklist = localItems.blacklist || [];
        whitelist = localItems.whitelist || [];
        blacklistKeywords = localItems.blacklistKeywords || [];
        whitelistKeywords = localItems.whitelistKeywords || [];
        mode = localItems.mode || defaultMode;
        framesType = localItems.framesType || defaultFramesType;
      } catch (localError) {
        logError('Error retrieving from local storage fallback, using defaults:', localError);
      }
    }
    
    // Always get local settings from local storage
    try {
      const localItems = await chrome.storage.local.get(localSettings);
      logInfo('Retrieved local settings', localItems);
      
      // Update local state
      isEnabled = localItems.isEnabled ?? defaultIsEnabled;
      timerSettings = { ...defaultTimerSettings, ...localItems.timer };
      enableLogs = localItems.enableLogs ?? false;
    } catch (error) {
      logError('Error retrieving local settings, using defaults:', error);
    }    // Verify rule integrity - ensure we have proper arrays
    if (!Array.isArray(blacklist)) {
      logInfo('[CRITICAL] Deny list is not an array after initialization, fixing');
      blacklist = [];
    }
    
    if (!Array.isArray(whitelist)) {
      logInfo('[CRITICAL] Allow list is not an array after initialization, fixing');
      whitelist = [];
    }
    
    if (!Array.isArray(blacklistKeywords)) {
      logInfo('[CRITICAL] Deny list keywords is not an array after initialization, fixing');
      blacklistKeywords = [];
    }
    
    if (!Array.isArray(whitelistKeywords)) {
      logInfo('[CRITICAL] Allow list keywords is not an array after initialization, fixing');
      whitelistKeywords = [];
    }
    
    // If we don't have any rules but we're not on a fresh install, verify rules integrity
    const totalRules = blacklist.length + whitelist.length + blacklistKeywords.length + whitelistKeywords.length;
    
    if (totalRules === 0 && !isInitialInstall) {
      logInfo('[CRITICAL] No rules found after initialization, triggering verification');
      
      // Run rule verification asynchronously - this will populate rules if needed
      setTimeout(async () => {
        try {
          const integrityCheck = await verifyRulesIntegrity();
          if (integrityCheck.restored) {
            logInfo(`[RECOVERY] Rules restored from ${integrityCheck.source}: ${integrityCheck.ruleCount} total`);
            setupBlockingRules();
            if (isEnabled) {
              checkAllTabs('init-recovery-check');
            }
          }
        } catch (integrityError) {
          logError('Error during initialization integrity check:', integrityError);
        }
      }, 0);
    }
    
    // Log details of blacklist for debugging
    logInfo(`RULES LOADED - Total rules loaded: ${blacklist.length + whitelist.length + blacklistKeywords.length + whitelistKeywords.length}`);
    logInfo(`Deny list: ${blacklist.length} rules, Allow list: ${whitelist.length} rules`);
    logInfo(`Deny keywords: ${blacklistKeywords.length}, Allow keywords: ${whitelistKeywords.length}`);
    logInfo('First few deny list items:', blacklist.slice(0, 5)); // Show first 5 items
    logInfo('First few allow list items:', whitelist.slice(0, 5)); // Show first 5 items
    logInfo('Deny list keywords:', blacklistKeywords);
    logInfo('Allow list keywords:', whitelistKeywords);
    
    // Setup navigation listener for URL blocking
    setupNavigationListener();
    
    // Check all open tabs against the current rules
    if (isEnabled) {
      logInfo('Checking all open tabs against blocking rules');
      checkAllTabs();
    }
    
    // Set up periodic sync checking
    setupPeriodicSyncCheck();

    logInfo('Service worker initialized successfully');
  } catch (error) {
    logError('Error initializing service worker:', error);
  }
}

// Keep the clearPasswordProtection function as a utility, but don't call it automatically
async function clearPasswordProtection() {
  logInfo('EMERGENCY: Clearing password protection settings');
  try {
    // Get the current password settings
    const { password } = await chrome.storage.local.get({ password: {} });
    
    // Create a clean password settings object
    const cleanPasswordSettings = {
      isEnabled: false,
      hash: '',
      allowActivationWithoutPassword: true,
      allowAddingWebsitesWithoutPassword: true,
      blockAccessToExtensionsPage: false
    };
    
    // Update storage with clean password settings
    await chrome.storage.local.set({ 
      password: cleanPasswordSettings 
    });
    
    logInfo('Password protection has been disabled');
    return true;
  } catch (error) {
    logError('Failed to clear password protection:', error);
    return false;
  }
}

// Add more comprehensive navigation capture with proper feature detection
function setupNavigationListener() {
  try {
    // Remove any existing listeners first to avoid duplicates
    chrome.webNavigation.onBeforeNavigate.removeListener(navigationHandler);
    chrome.tabs.onUpdated.removeListener(tabsUpdatedHandler);
    
    // Only try to remove webRequest listener if API exists
    if (chrome.webRequest) {
      chrome.webRequest.onBeforeRequest.removeListener(webRequestHandler);
    }
  } catch (e) {
    // Ignore if any don't exist
    logInfo('Error removing existing listeners (can be ignored):', e);
  }
  
  // Add our navigation handlers
  // 1. Primary navigation listener - catches direct address bar navigations
  chrome.webNavigation.onBeforeNavigate.addListener(navigationHandler);
  logInfo('Added webNavigation.onBeforeNavigate listener');
  
  // 2. Tabs updated listener - catches some navigation that might be missed
  chrome.tabs.onUpdated.addListener(tabsUpdatedHandler);
  logInfo('Added tabs.onUpdated listener');
  
  // 3. Web request listener - only if available
  if (chrome.webRequest) {
    try {
      // Try with blocking option first (works in Firefox)
      chrome.webRequest.onBeforeRequest.addListener(
        webRequestHandler,
        { urls: ["<all_urls>"], types: ["main_frame"] },
        ["blocking"]
      );
      logInfo('Added blocking webRequest.onBeforeRequest listener');
    } catch (e) {
      logError('Unable to add blocking webRequest listener:', e);
      try {
        // Fall back to non-blocking (doesn't prevent navigation but can redirect)
        chrome.webRequest.onBeforeRequest.addListener(
          webRequestHandler,
          { urls: ["<all_urls>"], types: ["main_frame"] }
        );
        logInfo('Added non-blocking webRequest.onBeforeRequest listener');
      } catch (err) {
        logError('Unable to add any webRequest listener:', err);
      }
    }
  } else {
    logInfo('webRequest API not available in this browser/context');
  }
  
  logInfo('Navigation listeners setup complete');

  // Set up storage change listener (important for syncing across devices)
  setupStorageChangeListener();
}

// Set up a listener for storage changes to detect when settings are updated on other devices
function setupStorageChangeListener() {
  try {
    // Remove existing listener if any to avoid duplicates
    chrome.storage.onChanged.removeListener(handleStorageChanges);
    
    // Add the listener
    chrome.storage.onChanged.addListener(handleStorageChanges);
    logInfo('Added storage change listener for cross-device syncing');
  } catch (error) {
    logError('Failed to setup storage change listener:', error);
  }
}

// Handler for storage changes
function handleStorageChanges(changes, areaName) {
  logInfo(`Storage changes detected in ${areaName}:`, changes);
  
  // Only process sync changes
  if (areaName !== 'sync') {
    return;
  }
  
  let shouldUpdateRules = false;
    // Process changes in deny list (blacklist)
  if (changes.blacklist) {
    const oldCount = Array.isArray(changes.blacklist.oldValue) ? changes.blacklist.oldValue.length : 0;
    const newCount = Array.isArray(changes.blacklist.newValue) ? changes.blacklist.newValue.length : 0;
    
    logInfo(`Deny list updated from sync storage: ${oldCount} → ${newCount} items`);
    
    // Only update if we have items or if we explicitly want to clear (not on undefined)
    if (changes.blacklist.newValue === null || Array.isArray(changes.blacklist.newValue)) {
      blacklist = Array.isArray(changes.blacklist.newValue) ? changes.blacklist.newValue : [];
      shouldUpdateRules = true;
    } else {
      logInfo('Ignoring undefined/invalid deny list update from sync storage');
    }
  }
  
  // Process changes in allow list (whitelist)
  if (changes.whitelist) {
    const oldCount = Array.isArray(changes.whitelist.oldValue) ? changes.whitelist.oldValue.length : 0;
    const newCount = Array.isArray(changes.whitelist.newValue) ? changes.whitelist.newValue.length : 0;
    
    logInfo(`Allow list updated from sync storage: ${oldCount} → ${newCount} items`);
    
    // Only update if we have items or if we explicitly want to clear (not on undefined)
    if (changes.whitelist.newValue === null || Array.isArray(changes.whitelist.newValue)) {
      whitelist = Array.isArray(changes.whitelist.newValue) ? changes.whitelist.newValue : [];
      shouldUpdateRules = true;
    } else {
      logInfo('Ignoring undefined/invalid allow list update from sync storage');
    }
  }
  
  // Process changes in deny list keywords
  if (changes.blacklistKeywords) {
    const oldCount = Array.isArray(changes.blacklistKeywords.oldValue) ? changes.blacklistKeywords.oldValue.length : 0;
    const newCount = Array.isArray(changes.blacklistKeywords.newValue) ? changes.blacklistKeywords.newValue.length : 0;
    
    logInfo(`Deny list keywords updated from sync storage: ${oldCount} → ${newCount} items`);
    
    // Only update if we have items or if we explicitly want to clear (not on undefined)
    if (changes.blacklistKeywords.newValue === null || Array.isArray(changes.blacklistKeywords.newValue)) {
      blacklistKeywords = Array.isArray(changes.blacklistKeywords.newValue) ? changes.blacklistKeywords.newValue : [];
      shouldUpdateRules = true;
    } else {
      logInfo('Ignoring undefined/invalid deny list keywords update from sync storage');
    }
  }
  
  // Process changes in allow list keywords
  if (changes.whitelistKeywords) {
    const oldCount = Array.isArray(changes.whitelistKeywords.oldValue) ? changes.whitelistKeywords.oldValue.length : 0;
    const newCount = Array.isArray(changes.whitelistKeywords.newValue) ? changes.whitelistKeywords.newValue.length : 0;
    
    logInfo(`Allow list keywords updated from sync storage: ${oldCount} → ${newCount} items`);
    
    // Only update if we have items or if we explicitly want to clear (not on undefined)
    if (changes.whitelistKeywords.newValue === null || Array.isArray(changes.whitelistKeywords.newValue)) {
      whitelistKeywords = Array.isArray(changes.whitelistKeywords.newValue) ? changes.whitelistKeywords.newValue : [];
      shouldUpdateRules = true;
    } else {
      logInfo('Ignoring undefined/invalid allow list keywords update from sync storage');
    }
  }
  
  // Process changes in mode
  if (changes.mode) {
    logInfo('Mode updated from sync storage:', changes.mode.newValue);
    mode = changes.mode.newValue || defaultMode;
    shouldUpdateRules = true;
  }
  
  // Process changes in framesType
  if (changes.framesType) {
    logInfo('Frames type updated from sync storage:', changes.framesType.newValue);
    framesType = changes.framesType.newValue || defaultFramesType;
    shouldUpdateRules = true;
  }  // Update the blocking rules if necessary
  if (shouldUpdateRules) {
    // Protect against losing all rules by verifying before updating
    const totalRules = blacklist.length + whitelist.length + 
                       blacklistKeywords.length + whitelistKeywords.length;
                       
    logInfo(`Storage update detected: Now have ${totalRules} total rules (${blacklist.length} deny, ${whitelist.length} allow)`);
                       
    // If all lists are empty, verify with local storage before proceeding
    if (totalRules === 0 && !isInitialInstall) {
      logWarning('CRITICAL: All rules appear to be empty after sync update. Verifying with local storage...');
      
      (async () => {
        try {
          // First, check if sync is genuinely empty or just not yet populated
          try {
            const syncBytesInUse = await new Promise((resolve) => {
              chrome.storage.sync.getBytesInUse(null, (bytes) => {
                resolve(bytes || 0);
              });
            });
            
            logInfo(`Sync storage contains ${syncBytesInUse} bytes of data`);
            
            // If sync is actively in use but our update had empty rules, this is suspicious
            if (syncBytesInUse > 0) {
              // Try an explicit get to see if we can get rules directly
              const directSyncData = await chrome.storage.sync.get(['blacklist', 'whitelist']);
              logInfo('Direct sync query results:', {
                hasBlacklist: !!directSyncData.blacklist,
                blacklistLength: Array.isArray(directSyncData.blacklist) ? directSyncData.blacklist.length : 'not array',
                hasWhitelist: !!directSyncData.whitelist,
                whitelistLength: Array.isArray(directSyncData.whitelist) ? directSyncData.whitelist.length : 'not array'
              });
              
              // If the direct query got rules, use them
              const directSyncRuleCount = 
                (Array.isArray(directSyncData.blacklist) ? directSyncData.blacklist.length : 0) + 
                (Array.isArray(directSyncData.whitelist) ? directSyncData.whitelist.length : 0);
                
              if (directSyncRuleCount > 0) {
                logInfo(`Found ${directSyncRuleCount} rules through direct sync query, using these`);
                
                if (Array.isArray(directSyncData.blacklist) && directSyncData.blacklist.length > 0) {
                  blacklist = directSyncData.blacklist;
                }
                if (Array.isArray(directSyncData.whitelist) && directSyncData.whitelist.length > 0) {
                  whitelist = directSyncData.whitelist;
                }
                
                // Also update local storage as backup
                await chrome.storage.local.set({
                  blacklist,
                  whitelist
                });
                
                // Skip local storage check since we got rules from sync
                setupBlockingRules();
                blockedUrls.clear();
                
                logInfo('Rules updated from direct sync query, checking all tabs');
                if (isEnabled) {
                  checkAllTabs('sync-update-with-direct-sync-fix');
                }
                
                // We handled the update, exit early
                return;
              }
            }
          } catch (syncBytesError) {
            logError('Error checking sync storage size:', syncBytesError);
          }
          
          // Continue with local storage check
          const localData = await chrome.storage.local.get({
            blacklist: [],
            whitelist: [],
            blacklistKeywords: [],
            whitelistKeywords: []
          });
          
          const localRuleCount = 
            (Array.isArray(localData.blacklist) ? localData.blacklist.length : 0) + 
            (Array.isArray(localData.whitelist) ? localData.whitelist.length : 0);
            
          logInfo(`Local storage has ${localRuleCount} rules`);
          
          if (localRuleCount > 0) {
            // We have rules in local storage but sync sent us empty rules
            // This could mean sync hasn't loaded all data yet
            logWarning('IMPORTANT: Local rules exist but sync sent empty rules. Using local rules as fallback.');
            
            // Update in-memory rules with local storage values rather than empty sync values
            if (Array.isArray(localData.blacklist) && localData.blacklist.length > 0) {
              blacklist = localData.blacklist;
              logInfo(`Using ${blacklist.length} deny rules from local storage instead of empty sync rules`);
            }
            
            if (Array.isArray(localData.whitelist) && localData.whitelist.length > 0) {
              whitelist = localData.whitelist;
              logInfo(`Using ${whitelist.length} allow rules from local storage instead of empty sync rules`);
            }
            
            if (Array.isArray(localData.blacklistKeywords) && localData.blacklistKeywords.length > 0) {
              blacklistKeywords = localData.blacklistKeywords;
            }
            
            if (Array.isArray(localData.whitelistKeywords) && localData.whitelistKeywords.length > 0) {
              whitelistKeywords = localData.whitelistKeywords;
            }
            
            // Save these to sync storage if it's empty
            // This helps resolve cases where sync storage had issues
            try {
              logInfo('Attempting to restore local rules to sync storage');
              await chrome.storage.sync.set({
                blacklist,
                whitelist,
                blacklistKeywords,
                whitelistKeywords
              });
              logInfo('Successfully restored rules to sync storage');
            } catch (syncWriteError) {
              logError('Error writing rules back to sync storage:', syncWriteError);
            }
          } else {
            // No rules in local storage either - call verifyRulesIntegrity which will try all options
            logWarning('CRITICAL: No rules in local storage either, attempting complete rule verification');
            const integrityResult = await verifyRulesIntegrity();
            logInfo('Rule integrity check result:', integrityResult);
          }
          
          // Now set up rules
          setupBlockingRules();
          blockedUrls.clear();
          
          logInfo(`Rules updated, now have ${blacklist.length} deny rules and ${whitelist.length} allow rules. Checking all tabs`);
          if (isEnabled) {
            checkAllTabs('sync-update-with-local-fallback');
          }
        } catch (error) {
          logError('Error verifying rules with local storage:', error);
          
          // Call verifyRulesIntegrity as a last resort
          try {
            logWarning('CRITICAL: Error during rule verification, attempting integrity check');
            await verifyRulesIntegrity();
          } catch (integrityError) {
            logError('Error during integrity check:', integrityError);
          }
          
          // Fall back to normal behavior
          setupBlockingRules();
          blockedUrls.clear();
          if (isEnabled) {
            checkAllTabs('sync-update-fallback-error');
          }
        }
      })();
    } else {
      // Normal case - we have rules after sync update
      logInfo(`Settings changed on another device, updating blocking rules (${totalRules} total rules)`);
      setupBlockingRules();
      
      // Clear the blocked URLs cache
      blockedUrls.clear();
      
      // Check all open tabs against the updated rules
      if (isEnabled) {
        logInfo('Re-evaluating all open tabs with new rules from sync');
        checkAllTabs('sync-update');
      }
    }
  }
}

// Handler for chrome.tabs.onUpdated events
function tabsUpdatedHandler(tabId, changeInfo, tab) {
  // Only handle URL changes in loading phase
  if (changeInfo.status === 'loading' && changeInfo.url) {
    logInfo(`Tab updated navigation to: ${changeInfo.url} [tabs.onUpdated]`);
    
    // Process the URL through our standard handler
    handleUrl(changeInfo.url, tabId, 'tabs.onUpdated');
  }
}

// Handler for chrome.webRequest.onBeforeRequest events
// Modified to handle the case when the API doesn't support blocking
function webRequestHandler(details) {
  if (details.type === 'main_frame') {
    logInfo(`Web request to: ${details.url} [webRequest.onBeforeRequest]`);
    
    // Process the URL 
    const result = handleUrl(details.url, details.tabId, 'webRequest.onBeforeRequest');
    
    // Return blocking response if function supports it (chrome.webRequest API with blocking permission)
    if (result && chrome.webRequest && chrome.webRequest.onBeforeRequest.hasListener) {
      return { cancel: true }; // Block and let our redirect handler take over
    }
  }
  
  // Don't return anything for non-blocking listeners
  // This prevents "Function returned a value that is not convertible to Dictionary" errors
  if (chrome.webRequest && chrome.webRequest.onBeforeRequest.hasListener) {
    return { cancel: false };
  }
}

// Centralized URL handler to ensure consistent handling
function handleUrl(url, tabId, source) {
  try {
    // Skip our own redirect pages
    const indexUrl = chrome.runtime.getURL('index.html');
    if (url.startsWith(indexUrl)) {
      logInfo(`Skipping redirect page: ${url} (source: ${source})`);
      return false;
    }
    
    // Normalize the URL for consistency
    const normalizedUrl = normalizeUrl(url);
    
    // First check our blocked URLs cache for quick rejection
    if (blockedUrls.has(url) || blockedUrls.has(normalizedUrl)) {
      logInfo(`URL found in blocked cache: ${url} (source: ${source}) - blocking`);
      // Even if it's in cache, we need a reason. Let's re-check, but this might be inefficient.
      // A better approach might be to store the reason in the cache too.
      // For now, let's re-evaluate to get the reason.
      const blockDetails = checkUrlShouldBeBlocked(normalizedUrl);
      redirectToBlockedPage(tabId, url, blockDetails.reason || "Cached block");
      return true;
    }

    // Only proceed if extension is enabled
    if (!isEnabled) {
      logInfo(`Extension disabled, allowing URL: ${url} (source: ${source})`);
      return false;
    }
    
    // Verify we have rules to check against (this helps if rules were lost)
    if ((!Array.isArray(blacklist) || blacklist.length === 0) && 
        (!Array.isArray(whitelist) || whitelist.length === 0)) {
      logInfo(`[CRITICAL] No rules found when checking URL: ${url} - attempting rule verification`);
      
      // Try to asynchronously verify rules, but we can't wait since this needs to be synchronous
      setTimeout(async () => {
        await verifyRulesIntegrity();
        // After verifying, refresh rules in memory and setup
        setupBlockingRules();
        logInfo(`Rules verification complete, now have: ${blacklist.length} deny rules, ${whitelist.length} allow rules`);
      }, 0);
      
      logInfo(`ALLOWING URL (due to missing rules): ${normalizedUrl} (source: ${source}) - rule verification initiated`);
      return false;
    }
    
    // Check if URL should be blocked
    const blockDetails = checkUrlShouldBeBlocked(normalizedUrl);
    
    if (blockDetails.blocked) {
      logInfo(`BLOCKING URL: ${normalizedUrl} (source: ${source}), Reason: ${blockDetails.reason}`);
      blockedUrls.add(url); // Cache original URL
      blockedUrls.add(normalizedUrl); // Cache normalized URL
      redirectToBlockedPage(tabId, url, blockDetails.reason);
      return true;
    } else {
      logInfo(`ALLOWING URL: ${normalizedUrl} (source: ${source}), Reason: ${blockDetails.reason}`);
      return false;
    }
  } catch (error) {
    logError(`Error handling URL ${url}:`, error);
    // Default to allowing on error
    return false;
  }
}

// Update the existing navigation handler to use the central handler
function navigationHandler(details) {
  if (details.frameId === 0) { // Only block main frame navigations
    logInfo(`Navigation attempt to: ${details.url} (via navigationHandler)`);

    // Only check if extension is enabled
    if (!isEnabled) {
      logInfo('Extension disabled, allowing navigation (via navigationHandler)');
      return;
    }

    // Check if URL should be blocked
    const blockDetails = checkUrlShouldBeBlocked(details.url); // Returns { blocked, reason }

    if (blockDetails.blocked) { // Corrected condition to check blockDetails.blocked
      // Block the navigation by redirecting to the blocked page
      logInfo(`BLOCKING navigation to: ${details.url}, Reason: ${blockDetails.reason} (via navigationHandler)`);
      redirectToBlockedPage(details.tabId, details.url, blockDetails.reason); // Use redirectToBlockedPage to include reason
    } else {
      logInfo(`ALLOWING navigation to: ${details.url}, Reason: ${blockDetails.reason} (via navigationHandler)`);
      // No action needed if not blocked
    }
  }
}
// Add enhanced diagnostic functions to troubleshoot specific URL issues

// Add enhanced debugging option
let ENABLE_DEEP_DEBUGGING = false;
function deepLog(message, data) {
  if (ENABLE_DEEP_DEBUGGING) {
    console.log(`[DMN DEBUG] ${message}`, data || '');
  }
}

// Add a consistent navigation handler to ensure URLs remain blocked

// We need to track URLs we've decided to block to prevent edge cases with redirects
let blockedUrls = new Set();

// Extract the redirect logic to a separate function
function redirectToBlockedPage(tabId, url, reason) {
  const indexUrl = chrome.runtime.getURL('index.html');
  const encodedUrl = encodeURIComponent(url);
  // Safeguard: if reason is empty or falsy, provide a default.
  const effectiveReason = reason || "Unknown reason for block";
  const encodedReason = encodeURIComponent(effectiveReason);
  chrome.tabs.update(tabId, {
    url: `${indexUrl}#/blocked?url=${encodedUrl}&reason=${encodedReason}`
  });
}

// Keep the URL normalization function for consistency
function normalizeUrl(url) {
  try {
    // Try to parse the URL
    const parsedUrl = new URL(url);
    
    // For reddit specifically, normalize the domain so all forms match the same pattern
    if (parsedUrl.hostname === 'reddit.com') {
      parsedUrl.hostname = 'www.reddit.com';
      return parsedUrl.toString();
    }
    
    return url;
  } catch (e) {
    // If parsing fails, return the original URL
    return url;
  }
}

// Fix checkUrlShouldBeBlocked to remove overly aggressive Reddit blocking
function checkUrlShouldBeBlocked(url) {
  // Always allow internal browser pages
  if (url.startsWith('edge://') || url.startsWith('chrome://')) {
    logInfo(`Allowing internal browser page: ${url}`);
    return { blocked: false, reason: "Internal browser page" };
  }

  // If not enabled, don't block anything
  if (!isEnabled) {
    return { blocked: false, reason: "Extension disabled" };
  }
  
  logInfo(`Checking URL against rules: ${url}`);
  
  // Step 1: Parse URL for hostname matching
  let hostname = "";
  try {
    const parsedUrl = new URL(url);
    hostname = parsedUrl.hostname.toLowerCase();
    logInfo(`URL hostname: ${hostname}`);
  } catch (e) {
    // Not a valid URL, continue with normal checks
    logInfo(`URL parsing failed, will use full URL: ${e.message}`);
  }
    // Step 2: Check if URL is in allow list (should override deny list)
  let isWhitelisted = false; // isAllowed (kept for compatibility)
  let whitelistedBy = null; // allowedBy (kept for compatibility)
  
  // Check site patterns in allow list
  for (const site of whitelist) {
    try {
      const pattern = typeof site === 'string' ? site : site.pattern || site.url;
      if (!pattern) continue;
      
      const regexPattern = wildcardToRegExp(pattern.replace(/^\^|\$/g, ''));
      
      // Try to match both full URL and hostname (if available)
      if (regexPattern.test(url) || (hostname && regexPattern.test(hostname))) {        logInfo(`URL MATCHED allow list pattern: ${pattern} - allowing access`);
        isWhitelisted = true;
        whitelistedBy = `Allow List pattern: ${pattern}`;
        break;
      }
    } catch (e) {
      logError('Error checking whitelist pattern:', e);
    }
  }
  
  // Check keywords in whitelist
  if (!isWhitelisted) {
    for (const keyword of whitelistKeywords) {
      try {
        const pattern = typeof keyword === 'string' ? keyword : keyword.pattern || keyword;
        if (!pattern) continue;
        
        if (url.toLowerCase().includes(pattern.toLowerCase()) || 
            (hostname && hostname.toLowerCase().includes(pattern.toLowerCase()))) {
          logInfo(`URL MATCHED whitelist keyword: ${pattern} - allowing access`);
          isWhitelisted = true;
          whitelistedBy = `Allow List keyword: ${pattern}`;
          break; 
        }
      } catch (e) {
        logError('Error checking whitelist keyword:', e);
      }
    }
  }    // If URL is explicitly in allow list, always allow regardless of mode or deny list
  if (isWhitelisted) {
    return { blocked: false, reason: whitelistedBy };
  }
  
  // Step 3: In allow list mode, block everything not in allow list
  if (mode === 'whitelist' || mode === 'allowlist') {
    logInfo(`URL not in allow list: ${url} - blocking access`);
    return { blocked: true, reason: "URL not on Allow List (Allow List Mode)" }; 
  }
  
  // Step 4: In deny list or combined modes, check against deny list
  if (mode === 'blacklist' || mode === 'denylist' || mode === 'combined') {
    // Try direct hostname match first (more reliable)
    if (hostname) {
      for (const site of blacklist) {
        try {
          const pattern = typeof site === 'string' ? site : site.pattern || site.url;
          if (!pattern) continue;
          
          const patternLower = pattern.toLowerCase().trim();
          
          // Direct domain comparison (very reliable)
          if (hostname === patternLower || hostname.endsWith('.' + patternLower)) {
            if (mode === 'combined' && isWhitelisted) {
              logInfo(`Hostname '${hostname}' directly matched blacklist domain: ${pattern}, but was whitelisted by: ${whitelistedBy} - allowing access`);
              return { blocked: false, reason: whitelistedBy };
            }
            logInfo(`Hostname '${hostname}' directly matched blacklist domain: ${pattern} - blocking access`);
            return { blocked: true, reason: `Deny List pattern: ${pattern}` };
          }
        } catch (e) {
          logError('Error checking blacklist pattern direct match:', e);
        }
      }
    }
    
    // Check site patterns in blacklist using regex
    for (const site of blacklist) {
      try {
        const pattern = typeof site === 'string' ? site : site.pattern || site.url;
        if (!pattern) continue;
        
        const regexPattern = wildcardToRegExp(pattern.replace(/^\^|\$/g, ''));
        
        // Try to match both full URL and hostname
        if (regexPattern.test(url) || (hostname && regexPattern.test(hostname))) {
          if (mode === 'combined' && isWhitelisted) {
            logInfo(`URL MATCHED blacklist pattern: ${pattern}, but was whitelisted by: ${whitelistedBy} - allowing access`);
            return { blocked: false, reason: whitelistedBy };
          }
          logInfo(`URL MATCHED blacklist pattern: ${pattern} - blocking access`);
          return { blocked: true, reason: `Deny List pattern: ${pattern}` };
        }
      } catch (e) {
        logError('Error checking blacklist pattern:', e);
      }
    }
    
    // Check keywords in blacklist
    for (const keyword of blacklistKeywords) {
      try {
        const pattern = typeof keyword === 'string' ? keyword : keyword.pattern || keyword;
        if (!pattern) continue;
        
        const normalizedPattern = pattern.toLowerCase();
        const normalizedUrl = url.toLowerCase();
        
        if (normalizedUrl.includes(normalizedPattern) || 
            (hostname && hostname.includes(normalizedPattern))) {
          if (mode === 'combined' && isWhitelisted) {
            logInfo(`URL MATCHED blacklist keyword: ${pattern}, but was whitelisted by: ${whitelistedBy} - allowing access`);
            return { blocked: false, reason: whitelistedBy };
          }
          logInfo(`URL MATCHED blacklist keyword: ${pattern} - blocking access`);
          return { blocked: true, reason: `Deny List keyword: ${pattern}` };
        }
      } catch (e) {
        logError('Error checking blacklist keyword:', e);
      }
    }
  }
  
  // If we reach here, allow the URL
  logInfo(`URL didn't match any blocking rules: ${url} - allowing access`);
  return { blocked: false, reason: "URL allowed by default (no matching rules)" };
}

// Replace the checkUrlAgainstRules function with a call to our more comprehensive function
function checkUrlAgainstRules(url) {
  logInfo(`Checking URL against rules: ${url}`);
  const shouldBlock = checkUrlShouldBeBlocked(url);
  if (shouldBlock) {
    logInfo(`URL should be BLOCKED: ${url}`);
  }
}

// Utility function for testing URL matching
function testUrlMatch(url, pattern) {
  const regex = wildcardToRegExp(pattern);
  const isMatch = regex.test(url);
  console.log(`Testing URL: ${url} against pattern: ${pattern}`);
  console.log(`Regex: ${regex}`);
  console.log(`Result: ${isMatch ? 'MATCH' : 'NO MATCH'}`);
  
  // Try also with hostname extraction
  try {
    const parsedUrl = new URL(url);
    const hostname = parsedUrl.hostname;
    const hostnameMatch = regex.test(hostname);
    console.log(`Hostname: ${hostname}`);
    console.log(`Hostname match: ${hostnameMatch ? 'MATCH' : 'NO MATCH'}`);
  } catch (e) {
    console.log(`URL parsing failed: ${e.message}`);
  }
  
  return isMatch;
}

// Debug function to test domain matching
function testDomainMatching() {
  console.log("=== TESTING DOMAIN MATCHING ===");
  
  // Test with iptorrents.com
  testUrlMatch("https://iptorrents.com/t", "iptorrents.com");
  testUrlMatch("https://iptorrents.com/t?p=8#torrents", "iptorrents.com");
  testUrlMatch("https://www.iptorrents.com/t", "iptorrents.com");
  
  // Test with wildcards
  testUrlMatch("https://sub.example.com/page", "*.example.com");
  testUrlMatch("https://example.com/page", "*.example.com");
  
  // Test with uppercase/lowercase
  testUrlMatch("https://IPTORRENTS.COM/t", "iptorrents.com");
  
  console.log("=== END TESTING ===");
}

// Replace the setupBlockingRules function with a simpler version that doesn't use declarativeNetRequest
async function setupBlockingRules() {
  // We're no longer using declarativeNetRequest rules at all
  // This function is kept for backward compatibility
  
  // Just log the current configuration
  logInfo('Setting up URL blocking with navigation listener only');
  logInfo(`Mode: ${mode}, Enabled: ${isEnabled}`);
  logInfo(`Blacklist entries: ${blacklist.length}, Whitelist entries: ${whitelist.length}`);
  logInfo(`Blacklist keywords: ${blacklistKeywords.length}, Whitelist keywords: ${whitelistKeywords.length}`);
  
  // Clear any existing rules if they exist
  if (currentRules.length > 0) {
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: currentRules.map(rule => rule.id)
      });
    } catch (e) {
      // Ignore errors if the API isn't available
      logInfo('declarativeNetRequest API not used');
    }
    currentRules = [];
  }
}

// Function to verify rule integrity - useful to detect when rules are empty unexpectedly
function verifyRulesIntegrity() {
  // Log the current state of the rules
  const totalRules = blacklist.length + whitelist.length + blacklistKeywords.length + whitelistKeywords.length;
  logInfo(`[RULES VERIFY] Current rule count: ${totalRules} rules`);
  logInfo(`[RULES VERIFY] Deny list: ${blacklist.length}, Allow list: ${whitelist.length}`);
  
  // Check if we have suspiciously low rule count when we expect to have rules
  if (totalRules === 0 && !isInitialInstall) {
    logError('WARNING: Rules appear to be empty. This may indicate a synchronization issue.');
    
    // Try to reload rules from local storage
    (async () => {
      try {
        const localData = await chrome.storage.local.get({
          blacklist: [],
          whitelist: [],
          blacklistKeywords: [],
          whitelistKeywords: [],
          mode: defaultMode
        });
        
        const localRuleCount = 
          (Array.isArray(localData.blacklist) ? localData.blacklist.length : 0) + 
          (Array.isArray(localData.whitelist) ? localData.whitelist.length : 0) +
          (Array.isArray(localData.blacklistKeywords) ? localData.blacklistKeywords.length : 0) +
          (Array.isArray(localData.whitelistKeywords) ? localData.whitelistKeywords.length : 0);
          
        logInfo(`[RULES VERIFY] Local storage has ${localRuleCount} rules`);
        
        if (localRuleCount > 0) {
          logInfo('[RULES VERIFY] Restoring rules from local storage');
          
          // Update in-memory rules with local storage values
          if (Array.isArray(localData.blacklist)) blacklist = localData.blacklist;
          if (Array.isArray(localData.whitelist)) whitelist = localData.whitelist;
          if (Array.isArray(localData.blacklistKeywords)) blacklistKeywords = localData.blacklistKeywords;
          if (Array.isArray(localData.whitelistKeywords)) whitelistKeywords = localData.whitelistKeywords;
          if (localData.mode) mode = localData.mode;
          
          // Update rules
          setupBlockingRules();
          
          logInfo(`[RULES VERIFY] Rules restored - now have: Deny: ${blacklist.length}, Allow: ${whitelist.length}`);
        }
        
        // Also try sync storage
        const syncData = await chrome.storage.sync.get({
          blacklist: [],
          whitelist: [],
          blacklistKeywords: [],
          whitelistKeywords: [],
          mode: defaultMode
        });
        
        const syncRuleCount = 
          (Array.isArray(syncData.blacklist) ? syncData.blacklist.length : 0) + 
          (Array.isArray(syncData.whitelist) ? syncData.whitelist.length : 0) +
          (Array.isArray(syncData.blacklistKeywords) ? syncData.blacklistKeywords.length : 0) +
          (Array.isArray(syncData.whitelistKeywords) ? syncData.whitelistKeywords.length : 0);
          
        logInfo(`[RULES VERIFY] Sync storage has ${syncRuleCount} rules`);
        
        if (syncRuleCount > 0 && syncRuleCount > localRuleCount) {
          logInfo('[RULES VERIFY] Updating rules from sync storage');
          
          // Update in-memory rules with sync storage values
          if (Array.isArray(syncData.blacklist)) blacklist = syncData.blacklist;
          if (Array.isArray(syncData.whitelist)) whitelist = syncData.whitelist;
          if (Array.isArray(syncData.blacklistKeywords)) blacklistKeywords = syncData.blacklistKeywords;
          if (Array.isArray(syncData.whitelistKeywords)) whitelistKeywords = syncData.whitelistKeywords;
          if (syncData.mode) mode = syncData.mode;
          
          // Update rules
          setupBlockingRules();
          
          // Save to local storage for backup
          await chrome.storage.local.set({
            blacklist: blacklist,
            whitelist: whitelist,
            blacklistKeywords: blacklistKeywords,
            whitelistKeywords: whitelistKeywords,
            mode: mode
          });
          
          logInfo(`[RULES VERIFY] Rules restored from sync - now have: Deny: ${blacklist.length}, Allow: ${whitelist.length}`);
        }
      } catch (error) {
        logError('[RULES VERIFY] Error verifying rules:', error);
      }
    })();
  }
  
  return {
    total: totalRules,
    blacklistCount: blacklist.length,
    whitelistCount: whitelist.length,
    keywordsCount: blacklistKeywords.length + whitelistKeywords.length
  };
}

// Fix checkAllTabs function to detect blocked tabs more reliably
function checkAllTabs() {
  // Verify rules are loaded properly first
  const ruleStatus = verifyRulesIntegrity();
  
  logInfo(`Re-evaluating all tabs with current rules: ${ruleStatus.total} rules total`);
  chrome.tabs.query({}).then((tabs) => {
    logInfo(`Found ${tabs.length} tabs to evaluate with rules (${blacklist.length} deny rules, ${whitelist.length} allow rules)`);
    if (tabs.length > 0) {
      const indexUrl = chrome.runtime.getURL('index.html');
      
      for (const tab of tabs) {
        if (isEnabled) {
          // When extension is enabled, check if each tab should be blocked
          if (tab.url && tab.url.startsWith('http')) {
            logInfo(`Evaluating tab ${tab.id}: ${tab.url}`);
            handleUrl(tab.url, tab.id, 'checkAllTabs');
          } else if (tab.url) {
            logInfo(`Skipping non-http tab ${tab.id}: ${tab.url}`);
          }
        } else {
          // When extension is disabled, unblock any blocked tabs
          // More robust detection of blocked pages - match with or without the slash
          if (tab.url && (
              tab.url.includes(`${indexUrl}#blocked?url=`) || 
              tab.url.includes(`${indexUrl}#/blocked?url=`)
            )) {
            try {
              // Extract the original URL that was blocked - handle both formats
              let hash = new URL(tab.url).hash;
              if (hash.startsWith('#/')) {
                hash = hash.substring(2); // Remove the #/ prefix
              } else if (hash.startsWith('#')) {
                hash = hash.substring(1); // Remove the # prefix
              }
              
              const originalUrl = hash.split('url=')[1]?.split('&')[0];
              
              if (originalUrl) {
                const decodedUrl = decodeURIComponent(originalUrl);
                logInfo(`Unblocking tab: ${decodedUrl}`);
                chrome.tabs.update(tab.id, { url: decodedUrl });
              } else {
                logError('Could not extract original URL from hash: ' + hash);
                chrome.tabs.reload(tab.id);
              }
            } catch (e) {
              logError('Error extracting URL from blocked page:', e);
              // If we can't extract the URL, just reload the tab
              chrome.tabs.reload(tab.id);
            }
          }
        }
      }
    }
  }).catch(error => {
    logError('Error querying tabs:', error);
  });
}

// Update the checkTab function to use handleUrl directly
function checkTab(data, caller) {
  if (data && data.url) {
    handleUrl(data.url, data.tabId, caller);
  }
}

// Add a performance improvement for setIsEnabled with an immediate icon update
function setIsEnabled(value) {
  const wasEnabled = isEnabled;
  isEnabled = !!value;
  
  // Update icon immediately for better UX
  updateIcon();
  
  if (wasEnabled === isEnabled) {
    // No change, nothing to do
    return isEnabled;
  }
  
  if (!isEnabled) {
    // When disabling:
    // 1. Clear blocked URLs cache
    blockedUrls.clear();
    logInfo('Cleared blocked URLs cache due to disable');
    
    // 2. Unblock any blocked tabs
    logInfo('Unblocking any blocked tabs due to disable');
    checkAllTabs();
  } else {
    // When enabling, check all tabs against blocking rules
    logInfo('Checking all tabs against blocking rules due to enable');
    checkAllTabs();
  }
  
  chrome.storage.local.set({ isEnabled });
  logInfo(`Extension ${isEnabled ? 'enabled' : 'disabled'}`);
  return isEnabled;
}

// Update the updateIcon function for better handling
function updateIcon() {
  try {
    chrome.action.setIcon({
      path: isEnabled ? {
        16: 'icons/magnet-16.png',
        32: 'icons/magnet-32.png',
        48: 'icons/magnet-48.png',
        64: 'icons/magnet-64.png',
        128: 'icons/magnet-128.png',
      } : {
        16: 'icons/magnet-grayscale-16.png',
        32: 'icons/magnet-grayscale-32.png',
        48: 'icons/magnet-grayscale-48.png',
        64: 'icons/magnet-grayscale-64.png',
        128: 'icons/magnet-grayscale-128.png',
      }
    });
  } catch (e) {
    // Fall back to browserAction for compatibility
    try {
      chrome.browserAction.setIcon({
        path: isEnabled ? {
          16: 'icons/magnet-16.png',
          32: 'icons/magnet-32.png',
          48: 'icons/magnet-48.png',
          64: 'icons/magnet-64.png',
          128: 'icons/magnet-128.png',
        } : {
          16: 'icons/magnet-grayscale-16.png',
          32: 'icons/magnet-grayscale-32.png',
          48: 'icons/magnet-grayscale-48.png',
          64: 'icons/magnet-grayscale-64.png',
          128: 'icons/magnet-grayscale-128.png',
        }
      });
    } catch (err) {
      logError('Failed to update extension icon:', err);
    }
  }
}

// Enhanced message handler with more extension functionality
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  logInfo('Message received:', request.message);
  
  try {
    let response = null;
    
    // Handle specific message types
    switch (request.message) {
      case 'getIsEnabled':
        response = isEnabled;
        break;
        
      case 'setIsEnabled':
        response = setIsEnabled(request.params[0]);
        break;
        
      case 'getMode':
        response = mode;
        break;
        
      case 'setMode':
        mode = request.params[0];
        // Use sync storage for mode
        chrome.storage.sync.set({ mode }).catch(error => {
          logError('Failed to save to sync storage, falling back to local:', error);
          chrome.storage.local.set({ mode });
        });
        // Clear the blocked URLs cache when mode changes
        blockedUrls.clear();
        logInfo(`Mode changed to: ${mode}, cleared blocked URLs cache`);
        response = true;
        break;
        
      case 'getBlacklist':
        response = blacklist;
        break;
          case 'setBlacklist':
        logInfo('Updating blacklist with entries:', 
          request.params[0] ? request.params[0].length : 0);
        blacklist = request.params[0];
        
        // Use sync storage for lists, but not on fresh install with empty lists
        // to avoid overwriting existing cloud data
        if (!isLikelyFreshInstall() || blacklist.length > 0) {
          chrome.storage.sync.set({ blacklist }).catch(error => {
            logError('Failed to save to sync storage, falling back to local:', error);
            chrome.storage.local.set({ blacklist });
          });
        } else {
          logInfo('Skipped saving empty blacklist to sync on fresh install');
          chrome.storage.local.set({ blacklist });
        }
        
        // Clear the blocked URLs cache when blacklist rules change
        blockedUrls.clear();
        logInfo('Cleared blocked URLs cache due to blacklist update');
        // No need to call setupBlockingRules()
        response = true;
        break;
        
      case 'getWhitelist':
        response = whitelist;
        break;
          case 'setWhitelist':
        logInfo('Updating whitelist with entries:', 
          request.params[0] ? request.params[0].length : 0);
        whitelist = request.params[0];
        
        // Use sync storage for lists, but not on fresh install with empty lists
        // to avoid overwriting existing cloud data
        if (!isLikelyFreshInstall() || whitelist.length > 0) {
          chrome.storage.sync.set({ whitelist }).catch(error => {
            logError('Failed to save to sync storage, falling back to local:', error);
            chrome.storage.local.set({ whitelist });
          });
        } else {
          logInfo('Skipped saving empty whitelist to sync on fresh install');
          chrome.storage.local.set({ whitelist });
        }
        
        // Clear the blocked URLs cache when whitelist rules change
        blockedUrls.clear();
        logInfo('Cleared blocked URLs cache due to whitelist update');
        // No need to call setupBlockingRules()
        response = true;
        break;
        
      case 'getBlacklistKeywords':
        response = blacklistKeywords;
        break;
        
      case 'setBlacklistKeywords':
        logInfo('Updating blacklist keywords:', request.params[0]);
        blacklistKeywords = request.params[0];
        chrome.storage.local.set({ blacklistKeywords });
        // Clear the blocked URLs cache when blacklist keywords change
        blockedUrls.clear();
        logInfo('Cleared blocked URLs cache due to blacklist keywords update');
        // No need to call setupBlockingRules()
        response = true;
        break;
        
      case 'getWhitelistKeywords':
        response = whitelistKeywords;
        break;
        
      case 'setWhitelistKeywords':
        whitelistKeywords = request.params[0];
        chrome.storage.local.set({ whitelistKeywords });
        // Clear the blocked URLs cache when whitelist keywords change
        blockedUrls.clear();
        logInfo('Cleared blocked URLs cache due to whitelist keywords update');
        // No need to call setupBlockingRules()
        response = true;
        break;
        
      case 'getTimerSettings':
        response = timerSettings;
        break;
        
      case 'setTimerSettings':
        if (request.params && request.params[0]) {
          timerSettings = { 
            ...timerSettings, 
            ...request.params[0]
          };
        }
        response = true;
        break;
        
      case 'getSchedule':
        // Return basic schedule data
        response = { 
          isEnabled: false,
          days: {} 
        };
        break;
        
      case 'getUnblockSettings':
        // Return basic unblock settings
        response = { 
          isEnabled: false,
          unblockOnceTimeout: 30,
          displayNotificationOnTimeout: true,
          autoReblockOnTimeout: false,
          requirePassword: false
        };
        break;
        
      case 'getLogsSettings':
        // Return basic logs settings
        response = {
          isEnabled: false,
          maxLength: 100
        };
        break;
        
      case 'isTimerActive':
        // Implement a simple timer check (can be enhanced later)
        response = false;
        break;
        
      case 'isUrlStillBlocked':
        if (request.params && request.params[0]) {
          response = checkUrlShouldBeBlocked(request.params[0]);
        } else {
          response = false;
        }
        break;
        
      case 'debugUrlMatching':
        if (request.params && request.params[0]) {
          response = debugUrlMatching(request.params[0]);
        }
        break;
        
      case 'testProblematicUrl':
        response = safeDebugFunction(testProblematicUrl, request.params?.[0]);
        break;
        
      case 'testWhitelistPatternMatching':
        response = safeDebugFunction(testWhitelistPatternMatching);
        break;
        
      case 'clearBlockedCache':
        blockedUrls.clear();
        response = true;
        break;
        
      case 'testRedditNormalization':        response = safeDebugFunction(testRedditNormalization);
        break;            case 'ping':
        // Simple ping response for diagnostics
        logInfo('Ping received from diagnostics page');
        response = { 
          timestamp: Date.now(),
          status: 'alive',
          version: chrome.runtime.getManifest().version
        };
        break;
        
      case 'getCurrentSettings':
        // Return current settings to the requester
        logInfo('Current settings requested from diagnostics page');
        response = getCurrentSettings();
        break;
          case 'forceUpdateRules':
        // Force update rules and re-evaluate open tabs - useful when rules are synced from other devices
        logInfo('Force update rules request received');
        
        // Verify rules are loaded properly
        const ruleStatus = verifyRulesIntegrity();
        logInfo(`Current rule status: ${ruleStatus.total} rules total (deny: ${ruleStatus.blacklistCount}, allow: ${ruleStatus.whitelistCount})`);
        
        // Update blocking rules
        setupBlockingRules();
        
        // Clear the blocked URLs cache
        blockedUrls.clear();
        
        // Re-evaluate all open tabs with current rules
        if (isEnabled) {
          logInfo('Re-evaluating all open tabs with current rules');
          checkAllTabs('force-update-rules');
        }
        
        response = { 
          success: true, 
          timestamp: Date.now(), 
          message: `Rules updated and tabs re-evaluated (${ruleStatus.total} rules total)`
        };
        break;
        
      case 'reloadRulesFromLocalStorage':
        // Force reload rules from local storage - useful when rules disappear
        logInfo('Force reload rules from local storage requested');
        
        // Set up an immediate response
        response = { 
          success: true, 
          message: 'Reloading rules from local storage',
          timestamp: Date.now()
        };
        
        // Do the actual work asynchronously
        (async function() {
          try {
            const localRules = await chrome.storage.local.get({
              blacklist: [],
              whitelist: [],
              blacklistKeywords: [],
              whitelistKeywords: [],
              mode: defaultMode
            });
            
            const ruleCount = 
              (Array.isArray(localRules.blacklist) ? localRules.blacklist.length : 0) +
              (Array.isArray(localRules.whitelist) ? localRules.whitelist.length : 0) +
              (Array.isArray(localRules.blacklistKeywords) ? localRules.blacklistKeywords.length : 0) +
              (Array.isArray(localRules.whitelistKeywords) ? localRules.whitelistKeywords.length : 0);
              
            logInfo(`Found ${ruleCount} rules in local storage`);
            
            // Update in-memory rules
            blacklist = Array.isArray(localRules.blacklist) ? localRules.blacklist : [];
            whitelist = Array.isArray(localRules.whitelist) ? localRules.whitelist : [];
            blacklistKeywords = Array.isArray(localRules.blacklistKeywords) ? localRules.blacklistKeywords : [];
            whitelistKeywords = Array.isArray(localRules.whitelistKeywords) ? localRules.whitelistKeywords : [];
            mode = localRules.mode || defaultMode;
            
            // Set up rules
            setupBlockingRules();
            blockedUrls.clear();
            
            // Re-evaluate all open tabs if enabled
            if (isEnabled) {
              logInfo('Re-evaluating all open tabs with rules from local storage');
              const results = await checkAllTabs('reload-from-local-storage');
              logInfo(`Tab re-evaluation complete: ${results.checked} tabs checked, ${results.blocked} blocked`);
              
              // Send notification about reload completing
              chrome.runtime.sendMessage({
                type: 'rulesReloaded',
                data: {
                  source: 'local',
                  ruleCount,
                  denyListCount: blacklist.length,
                  allowListCount: whitelist.length,
                  tabsChecked: results.checked,
                  tabsBlocked: results.blocked
                }
              });
            }
          } catch (err) {
            logError('Error reloading rules from local storage:', err);
          }
        })();
        break;
          case 'forceCheckAllTabs':
        // Force re-evaluation of all tabs without changing rules
        logInfo('Force checking all tabs without rules update');
        
        if (isEnabled) {
          // Do the work asynchronously
          (async function() {
            try {
              // First verify rule integrity before checking tabs
              logInfo('First verifying rule integrity before checking tabs');
              const integrityCheck = await verifyRulesIntegrity();
              
              if (integrityCheck.restored) {
                logInfo(`Rule integrity check restored ${integrityCheck.ruleCount} rules from ${integrityCheck.source}`);
                setupBlockingRules(); // Re-setup rules since we restored them
              } else {
                logInfo(`Rule integrity check complete: Found ${blacklist.length} deny rules, ${whitelist.length} allow rules`);
              }
              
              // Now check all tabs with the verified rules
              const results = await checkAllTabs('manual-force-check');
              logInfo(`Force tab check complete: ${results.checked} tabs checked, ${results.blocked} tabs blocked`);
              
              // Send notification about the completed check
              chrome.runtime.sendMessage({
                type: 'tabsChecked',
                data: {
                  ...results,
                  ruleCountDeny: blacklist.length,
                  ruleCountAllow: whitelist.length,
                  timestamp: Date.now()
                }
              });
            } catch (err) {
              logError('Error during force tab check:', err);
            }
          })();
        } else {
          logInfo('Extension is disabled, skipping tab check');
        }
          response = { 
          success: true, 
          timestamp: Date.now(), 
          message: 'Force tab check initiated'
        };
        break;
        
      case 'refreshRulesFromCloud':
        // Direct pull from sync storage and force update rules
        logInfo('Refresh rules from cloud requested');
        
        // Set up an immediate response
        response = {
          success: true,
          message: 'Rules refresh from cloud initiated',
          timestamp: Date.now()
        };
        
        // Do the work asynchronously
        (async function() {
          try {
            logInfo('Pulling latest rules from sync storage');
            const syncPull = await forcePullFromSyncStorage();
            
            // Even if sync pull reports failure, try rule verification
            if (!syncPull) {
              logInfo('Sync pull reported issues, verifying rules integrity');
              const integrity = await verifyRulesIntegrity();
              logInfo('Rule integrity check result:', integrity);
            }
            
            // Log the current rule state
            logInfo(`Current rule state after refresh: ${blacklist.length} deny rules, ${whitelist.length} allow rules`);
            
            // Setup rules regardless of sync pull result
            setupBlockingRules();
            
            logInfo('Rules updated, re-evaluating tabs');
            if (isEnabled) {
              const results = await checkAllTabs('refreshed-from-cloud');
              logInfo(`Tab re-evaluation complete: ${results.checked} tabs checked, ${results.blocked} tabs blocked`);
              
              chrome.runtime.sendMessage({
                type: 'rulesRefreshedFromCloud',
                data: {
                  success: true,
                  ...results,
                  ruleCountDeny: blacklist.length,
                  ruleCountAllow: whitelist.length,
                  timestamp: Date.now()
                }
              });
            } else {
              logInfo('Extension disabled, skipping tab re-evaluation');
            }
          } catch (err) {
            logError('Error refreshing rules from cloud:', err);
            
            chrome.runtime.sendMessage({
              type: 'rulesRefreshedFromCloud',
              data: {
                success: false,
                error: err.message,
                timestamp: Date.now()
              }
            });
          }
        })();
        break;
          
      case 'updateRules':
        // Force reload rules from sync storage and re-evaluate all tabs
        logInfo('Force reload rules from sync storage requested');
        
        // Set up an immediate response
        response = { 
          success: true, 
          message: 'Rules update from sync started',
          timestamp: Date.now()
        };
        
        // Do the actual work asynchronously
        (async function() {
          try {
            // Explicitly get the latest sync data first
            const syncSettings = {
              blacklist: [], 
              whitelist: [], 
              blacklistKeywords: [], 
              whitelistKeywords: [],
              mode: defaultMode,
              framesType: defaultFramesType,
              message: '', 
              redirectUrl: '',
              schedule: { isEnabled: false, days: {} }
            };
              
            // First try sync storage for the latest data
            logInfo('Explicitly requesting latest data from sync storage');
            const syncData = await chrome.storage.sync.get(syncSettings);
            
            // Create a safe result object with defaults for all expected values
            const safeSyncData = {
              // Default values
              blacklist: [], 
              whitelist: [], 
              blacklistKeywords: [], 
              whitelistKeywords: [],
              mode: defaultMode,
              framesType: defaultFramesType,
              message: '',
              redirectUrl: '',
              schedule: { isEnabled: false, days: {} },
              
              // Override with any valid values from syncData
              ...syncData
            };
            
            // Ensure we have valid arrays for lists
            safeSyncData.blacklist = Array.isArray(safeSyncData.blacklist) ? safeSyncData.blacklist : [];
            safeSyncData.whitelist = Array.isArray(safeSyncData.whitelist) ? safeSyncData.whitelist : [];
            safeSyncData.blacklistKeywords = Array.isArray(safeSyncData.blacklistKeywords) ? safeSyncData.blacklistKeywords : [];
            safeSyncData.whitelistKeywords = Array.isArray(safeSyncData.whitelistKeywords) ? safeSyncData.whitelistKeywords : [];
            
            // Log the data we retrieved
            const ruleCounts = {
              denyListCount: safeSyncData.blacklist.length,
              allowListCount: safeSyncData.whitelist.length,
              denyKeywordsCount: safeSyncData.blacklistKeywords.length,
              allowKeywordsCount: safeSyncData.whitelistKeywords.length,
              mode: safeSyncData.mode,
              framesType: safeSyncData.framesType
            };
            
            logInfo('Retrieved sync data:', ruleCounts);
            
            // Only update if we got meaningful data (not empty arrays)
            const hasRules = safeSyncData.blacklist.length > 0 || 
                            safeSyncData.whitelist.length > 0 || 
                            safeSyncData.blacklistKeywords.length > 0 || 
                            safeSyncData.whitelistKeywords.length > 0;
            
            if (!hasRules) {
              logInfo('WARNING: Retrieved sync data appears empty, checking existing rules before overwriting');
              
              // Check if we have existing rules
              const existingData = await chrome.storage.local.get({
                blacklist: [],
                whitelist: [],
                blacklistKeywords: [],
                whitelistKeywords: []
              });
              
              const hasExistingRules = existingData.blacklist.length > 0 || 
                                      existingData.whitelist.length > 0 || 
                                      existingData.blacklistKeywords.length > 0 || 
                                      existingData.whitelistKeywords.length > 0;
              
              if (hasExistingRules) {
                logInfo('Keeping existing rules instead of overwriting with empty data from sync');
                // Send notification about the skipped overwrite
                chrome.runtime.sendMessage({
                  type: 'syncRulesUpdateSkipped',
                  data: {
                    reason: 'Prevented overwrite of existing rules with empty sync data',
                    existingRuleCounts: {
                      denyListCount: existingData.blacklist.length,
                      allowListCount: existingData.whitelist.length,
                      denyKeywordsCount: existingData.blacklistKeywords.length,
                      allowKeywordsCount: existingData.whitelistKeywords.length
                    },
                    timestamp: Date.now()
                  }
                });
                return;
              }
            }
            
            // Update local storage with the latest sync data
            logInfo('Updating local storage with new rules from sync');
            await chrome.storage.local.set({
              blacklist: safeSyncData.blacklist,
              whitelist: safeSyncData.whitelist,
              blacklistKeywords: safeSyncData.blacklistKeywords,
              whitelistKeywords: safeSyncData.whitelistKeywords,
              mode: safeSyncData.mode,
              framesType: safeSyncData.framesType
            });
            
            // Now reinitialize everything
            logInfo('Reinitializing service worker with new rules');
            await init();
            setupBlockingRules();
            blockedUrls.clear();
            
            // Re-evaluate all open tabs if enabled
            if (isEnabled) {
              logInfo('Re-evaluating all tabs with fresh rules from sync');
              
              try {
                const tabResults = await checkAllTabs('manual-sync-update');
                logInfo(`Tab re-evaluation results: checked ${tabResults.checked}, blocked ${tabResults.blocked} tabs`);
                
                // Send a notification about the completed update with tab check results
                chrome.runtime.sendMessage({
                  type: 'syncRulesUpdated',
                  data: {
                    ...ruleCounts,
                    tabsChecked: tabResults.checked,
                    tabsBlocked: tabResults.blocked,
                    timestamp: Date.now()
                  }
                });
              } catch (err) {
                logError('Error re-evaluating tabs:', err);
              }
            } else {
              logInfo('Extension is disabled, skipping tab re-evaluation');
            }
              // Send a follow-up message with the results
            chrome.runtime.sendMessage({
              type: 'syncRulesUpdated',
              data: {
                success: true,
                blacklistCount: safeSyncData.blacklist.length,
                whitelistCount: safeSyncData.whitelist.length,
                timestamp: Date.now()
              }
            }).catch(() => {
              // Ignore errors if the message port is closed
            });
          } catch (error) {
            logError('Error updating rules from sync:', error);
            
            // Send error message
            chrome.runtime.sendMessage({
              type: 'syncRulesUpdateFailed',
              error: error.message
            }).catch(() => {
              // Ignore errors if the message port is closed  
            });
          }
        })();
        break;
        
      case 'forcePullFromSync':
        // Directly force pull from sync storage (more robust than updateRules)
        logInfo('Direct force pull from sync storage requested');
        
        // Set immediate response and do work asynchronously
        response = { success: true, message: 'Force pull started' };
        
        (async function() {
          try {
            // Call the force pull function and get the result
            const pullResult = await forcePullFromSyncStorage();
            
            // Send the result back to the requester
            chrome.runtime.sendMessage({
              type: 'forcePullComplete',
              data: {
                success: pullResult,
                blacklistCount: blacklist.length,
                whitelistCount: whitelist.length,
                timestamp: Date.now()
              }
            }).catch(() => {
              // Ignore errors if the message port is closed
            });
          } catch (error) {
            logError('Error force-pulling from sync:', error);
            
            // Send error message
            chrome.runtime.sendMessage({
              type: 'forcePullFailed',
              error: error.message
            }).catch(() => {
              // Ignore errors if the message port is closed
            });
          }
        })();
        break;
        
      case 'diagnoseSyncStatus':
        // Run detailed sync diagnostics
        logInfo('Detailed sync diagnostics requested');
        
        // Set immediate response
        response = { success: true, message: 'Sync diagnostics started' };
        
        // Do the work asynchronously
        (async function() {
          try {
            // Run the diagnostics if the function exists
            if (typeof self.diagnoseSyncStatus === 'function') {
              await self.diagnoseSyncStatus();
              
              // Try to get quota info for the response
              const quotaInfo = await self.getSyncStorageQuota();
              
              // Send the result back
              chrome.runtime.sendMessage({
                type: 'syncDiagnosticsComplete',
                data: {
                  quota: quotaInfo,
                  extensionId: chrome.runtime.id,
                  version: chrome.runtime.getManifest().version,
                  blacklistCount: blacklist.length,
                  whitelistCount: whitelist.length,
                  timestamp: Date.now()
                }
              }).catch(() => {
                // Ignore errors if the message port is closed
              });
            } else {
              logWarning('diagnoseSyncStatus function not available');
            }
          } catch (error) {
            logError('Error running sync diagnostics:', error);
          }
        })();
        break;
          case 'getSyncDiagnostics':
        // Get detailed sync diagnostics
        logInfo('Sync diagnostics requested');
        try {
          if (typeof self.getSyncStorageQuota === 'function') {
            self.getSyncStorageQuota().then(quotaInfo => {
              // Send the quota info back to the requester
              chrome.runtime.sendMessage({
                type: 'syncDiagnosticsResult',
                data: {
                  quota: quotaInfo,
                  extensionId: chrome.runtime.id,
                  version: chrome.runtime.getManifest().version,
                  timestamp: Date.now(),
                  syncStatus: 'active',
                  settings: {
                    blacklistCount: blacklist.length, 
                    whitelistCount: whitelist.length,
                    mode: mode
                  }
                }
              }).catch(() => {
                // Ignore errors if the message port is closed
                console.log('Failed to send sync diagnostics result - port closed');
              });
            }).catch(error => {
              console.error('Error getting sync storage quota:', error);
            });
          }
          response = { 
            success: true, 
            message: 'Sync diagnostics started',
            extensionId: chrome.runtime.id
          };
        } catch (error) {
          console.error('Error in sync diagnostics:', error);
          response = { success: false, error: error.message };
        }
        break;
        
      default:
        console.log('Unknown message type:', request.message);
        response = null;
        break;
    }
    
    console.log('Sending response:', response);
    sendResponse({ response });
  } catch (error) {
    console.error('Error handling message:', error);
    sendResponse({ error: error.message });
  }
  
  return true; // Keep the message channel open for async responses
});

// Add a debug function to test pattern matching
function debugUrlMatching(url) {
  logInfo(`=== DEBUG MATCHING FOR URL: ${url} ===`);
  
  logInfo('Whitelist pattern matches:');
  for (const site of whitelist) {
    try {
      const pattern = typeof site === 'string' ? site : site.pattern || site.url;
      if (!pattern) continue;
      
      const regexPattern = wildcardToRegExp(pattern.replace(/^\^|\$$/g, ''));
      const isMatch = regexPattern.test(url);
      logInfo(`  Pattern: ${pattern} => ${isMatch ? 'MATCH' : 'no match'}`);
    } catch (e) {
      logError('Error debugging whitelist pattern:', e);
    }
  }
  
  logInfo('Whitelist keyword matches:');
  for (const keyword of whitelistKeywords) {
    try {
      const pattern = typeof keyword === 'string' ? keyword : keyword.pattern || keyword;
      if (!pattern) continue;
      
      const isMatch = url.toLowerCase().includes(pattern.toLowerCase());
      logInfo(`  Keyword: ${pattern} => ${isMatch ? 'MATCH' : 'no match'}`);
    } catch (e) {
      logError('Error debugging whitelist keyword:', e);
    }
  }
  
  logInfo('Blacklist pattern matches:');
  for (const site of blacklist) {
    try {
      const pattern = typeof site === 'string' ? site : site.pattern || site.url;
      if (!pattern) continue;
      
      const regexPattern = wildcardToRegExp(pattern.replace(/^\^|\$$/g, ''));
      const isMatch = regexPattern.test(url);
      logInfo(`  Pattern: ${pattern} => ${isMatch ? 'MATCH' : 'no match'}`);
    } catch (e) {
      logError('Error debugging blacklist pattern:', e);
    }
  }
  
  logInfo('Blacklist keyword matches:');
  for (const keyword of blacklistKeywords) {
    try {
      const pattern = typeof keyword === 'string' ? keyword : keyword.pattern || keyword;
      if (!pattern) continue;
      
      const isMatch = url.toLowerCase().includes(pattern.toLowerCase());
      logInfo(`  Keyword: ${pattern} => ${isMatch ? 'MATCH' : 'no match'}`);
    } catch (e) {
      logError('Error debugging blacklist keyword:', e);
    }
  }
  
  const result = checkUrlShouldBeBlocked(url);
  logInfo(`Final result: ${result ? 'BLOCKED' : 'ALLOWED'}`);
  return result;
}

// Add a testing function specifically for whitelist pattern matching
function testWhitelistPatternMatching() {
  const testCases = [
    { 
      pattern: 'https://www.reddit.com/', 
      shouldMatch: ['https://www.reddit.com/', 'https://www.reddit.com/home'], 
      shouldNotMatch: ['https://www.reddit.com/r/redheads/', 'https://www.reddit.com/r/pics']
    },
    { 
      pattern: 'https://www.reddit.com/r/learnart/*', 
      shouldMatch: ['https://www.reddit.com/r/learnart/', 'https://www.reddit.com/r/learnart/comments/123'],
      shouldNotMatch: ['https://www.reddit.com/r/redheads/']
    },
    {
      pattern: 'https://www.reddit.com',
      shouldMatch: ['https://www.reddit.com'],
      shouldNotMatch: ['https://www.reddit.com/', 'https://www.reddit.com/r/anything']
    }
  ];
  
  console.log('===== WHITELIST PATTERN MATCHING TEST =====');
  
  testCases.forEach(testCase => {
    console.log(`\nTesting pattern: ${testCase.pattern}`);
    const regex = wildcardToRegExp(testCase.pattern);
    console.log(`Compiled regex: ${regex}`);
    
    testCase.shouldMatch.forEach(url => {
      const matches = regex.test(url);
      console.log(`${url} - ${matches ? '✓ MATCH (CORRECT)' : '✗ NO MATCH (ERROR)'}`);
    });
    
    testCase.shouldNotMatch.forEach(url => {
      const matches = regex.test(url);
      console.log(`${url} - ${!matches ? '✓ NO MATCH (CORRECT)' : '✗ MATCH (ERROR)'}`);
    });
  });
  
  console.log('\n=========================================');
}

// Add a utility function to manually test reddit URLs
function testRedditNormalization() {
  const urls = [
    'https://reddit.com/',
    'https://reddit.com',
    'https://www.reddit.com/',
    'https://www.reddit.com',
    'http://reddit.com/',
    'https://reddit.com/r/popular/',
    'https://www.reddit.com/r/redheads/'
  ];
  
  console.log('===== REDDIT URL NORMALIZATION TEST =====');
  urls.forEach(url => {
    const normalized = normalizeUrl(url);
    const isBlocked = checkUrlShouldBeBlocked(normalized);
    console.log(`Original: ${url}`);
    console.log(`Normalized: ${normalized}`);
    console.log(`Blocked: ${isBlocked ? 'YES' : 'NO'}`);
    console.log('-----------');
  });
}

// Add a function to get the current settings for the UI
function getCurrentSettings() {
  return {
    isEnabled,
    mode,
    blacklist,
    whitelist,
    blacklistKeywords,
    whitelistKeywords
  };
}

// Function to test if URL patterns match correctly
function testUrlMatching(url, pattern) {
  const regex = wildcardToRegExp(pattern);
  const isMatch = regex.test(url);
  console.log(`Testing if '${url}' matches pattern '${pattern}': ${isMatch ? 'YES' : 'NO'}`);
  console.log(`Regex used: ${regex.toString()}`);
  return isMatch;
}

// Test function for problematic domains
function testProblemDomains() {
  console.log("=== DOMAIN MATCHING TEST ===");
  
  // Test IPTORRENTS.COM
  testUrlMatching("https://iptorrents.com/some/path", "iptorrents.com");
  testUrlMatching("https://www.iptorrents.com", "iptorrents.com");
  testUrlMatching("https://sub.iptorrents.com/page", "iptorrents.com");
  testUrlMatching("http://iptorrents.com", "iptorrents.com");
  testUrlMatching("https://iptorrents.comextra.com", "iptorrents.com"); // Should NOT match
  
  // Test wildcard domains
  testUrlMatching("https://test.example.com", "*.example.com");
  testUrlMatching("https://example.com", "*.example.com"); // Should NOT match
  testUrlMatching("https://a.b.example.com", "*.example.com");
  
  // Test case sensitivity
  testUrlMatching("https://IPTORRENTS.COM", "iptorrents.com");
  testUrlMatching("https://iptorrents.com", "IPTORRENTS.COM");
  
  console.log("=== TEST COMPLETE ===");
}

// Initialize on install or update
chrome.runtime.onInstalled.addListener(details => {
  console.log('Extension installed or updated:', details.reason);
  
  // Set the initial install flag
  isInitialInstall = details.reason === 'install';
  
  // Log the reason and extension ID
  logInfo(`Extension ${details.reason}: ID=${chrome.runtime.id}, initial install=${isInitialInstall}`);
  
  // Extra diagnostics
  if (typeof self.diagnoseSyncStatus === 'function') {
    self.diagnoseSyncStatus();
  }
  
  // First init
  init().then(() => {
    logInfo('Initial initialization complete, waiting for sync to stabilize...');
    
    // If it's a fresh install, we need special handling to make sure we don't overwrite cloud data
    if (isInitialInstall) {
      // Check for existing data in sync storage first before doing anything
      logInfo('Fresh install detected. Checking for existing sync data...');
      
      // Create a sync check function that's more aggressive
      const checkSyncStorage = async (attempt = 1) => {
        try {
          logInfo(`Sync check attempt #${attempt} - Reading sync storage directly`);
          
          // Get all sync data
          const syncData = await chrome.storage.sync.get({
            blacklist: [],
            whitelist: [],
            blacklistKeywords: [],
            whitelistKeywords: []
          });
          
          // Count items
          const blacklistCount = Array.isArray(syncData.blacklist) ? syncData.blacklist.length : 0;
          const whitelistCount = Array.isArray(syncData.whitelist) ? syncData.whitelist.length : 0;
          
          logInfo(`Sync data check result: ${blacklistCount} deny, ${whitelistCount} allow items`);
          
          // If we found existing data in sync storage, use it
          const hasData = (blacklistCount > 0 || whitelistCount > 0);
          if (hasData) {
            logInfo('FOUND EXISTING SYNC DATA! Updating local storage with cloud data...');
            
            // Create a safe version of the sync data
            const safeData = {
              blacklist: Array.isArray(syncData.blacklist) ? syncData.blacklist : [],
              whitelist: Array.isArray(syncData.whitelist) ? syncData.whitelist : [],
              blacklistKeywords: Array.isArray(syncData.blacklistKeywords) ? syncData.blacklistKeywords : [],
              whitelistKeywords: Array.isArray(syncData.whitelistKeywords) ? syncData.whitelistKeywords : []
            };
            
            // Update local storage with sync data
            await chrome.storage.local.set(safeData);
            
            // Update memory variables too
            blacklist = safeData.blacklist;
            whitelist = safeData.whitelist;
            blacklistKeywords = safeData.blacklistKeywords;
            whitelistKeywords = safeData.whitelistKeywords;
            
            // Update rules based on the sync data
            setupBlockingRules();
            
            logInfo('Successfully updated local state with existing sync data');
            return true;
          } 
          
          // If we didn't find data and this is not the final attempt, try again later
          if (attempt < 6) {
            logInfo(`No sync data found yet (attempt ${attempt}/6). Will try again in 10 seconds...`);
            return false;
          }
          
          // This is the final attempt and no data was found
          logInfo('Final attempt complete. No existing sync data found. Proceeding with fresh install.');
          return false;
        } catch (error) {
          logError(`Error in sync check attempt #${attempt}:`, error);
          return false;
        }
      };
      
      // Immediate check
      checkSyncStorage(1).then(foundData => {
        if (!foundData) {
          // Schedule additional sync checks with increasing delays
          // This gives Chrome sync time to retrieve cloud data
          const delaysInSeconds = [10, 20, 30, 45, 60]; // Progressive backoff
          
          delaysInSeconds.forEach((seconds, index) => {
            setTimeout(() => {
              checkSyncStorage(index + 2); // Start from attempt 2
            }, seconds * 1000);
          });
        }
      });
      
      // Clear initial install flag after 2 minutes to allow normal operation
      setTimeout(() => {
        isInitialInstall = false;
        logInfo('Initial install phase completed, now allowing sync writes if needed');
      }, 120000); // 2 minutes
    }
  });
});

// Initialize on startup
chrome.runtime.onStartup.addListener(() => {
  console.log('Browser started');
  isInitialInstall = false; // Not a fresh install on browser startup
  init();
  
  // Start periodic sync check
  setupPeriodicSyncCheck();
});

// Set up a periodic sync check to ensure rules are up-to-date
function setupPeriodicSyncCheck() {
  // Check sync every 5 minutes
  const SYNC_CHECK_INTERVAL = 5 * 60 * 1000;
  
  // Initial check after 1 minute
  setTimeout(checkSyncStatus, 60 * 1000);
  
  // Then check periodically
  setInterval(checkSyncStatus, SYNC_CHECK_INTERVAL);
  
  logInfo('Periodic sync check scheduled');
}

// Function to check sync status and update rules if needed
async function checkSyncStatus() {
  logInfo('Performing periodic sync check');
  
  try {
    // Get current rules from sync storage with defaults
    const defaultSyncData = {
      blacklist: [],
      whitelist: [],
      blacklistKeywords: [],
      whitelistKeywords: [],
      mode: defaultMode,
      framesType: defaultFramesType
    };
    
    // Safely get data from sync storage
    const syncData = await chrome.storage.sync.get(defaultSyncData);
    
    // Create a safe result object with defaults for all expected values
    const safeSyncData = {
      // Default values
      blacklist: [], 
      whitelist: [], 
      blacklistKeywords: [], 
      whitelistKeywords: [],
      mode: defaultMode,
      framesType: defaultFramesType,
      
      // Override with any valid values from syncData
      ...syncData
    };
    
    // Safety check for arrays
    if (!Array.isArray(safeSyncData.blacklist)) safeSyncData.blacklist = [];
    if (!Array.isArray(safeSyncData.whitelist)) safeSyncData.whitelist = [];
    } else {
      // Check if the contents are different
      for (let i = 0; i < safeSyncData.blacklist.length; i++) {
        if (safeSyncData.blacklist[i] !== blacklist[i]) {
          logInfo('Deny list content changed in sync storage, updating');
          needsUpdate = true;
          break;
        }
      }
    }
    
    // Similarly for allow list
    if (!needsUpdate && safeSyncData.whitelist.length !== whitelist.length) {
      logInfo(`Allow list length changed in sync storage: ${whitelist.length} → ${safeSyncData.whitelist.length}`);
      needsUpdate = true;
    }
      // Update if needed
    if (needsUpdate) {
      logInfo('Updating rules from sync storage');
      
      try {
        // Update in-memory values with safe defaults
        blacklist = Array.isArray(safeSyncData.blacklist) ? safeSyncData.blacklist : [];
        whitelist = Array.isArray(safeSyncData.whitelist) ? safeSyncData.whitelist : [];
        blacklistKeywords = Array.isArray(safeSyncData.blacklistKeywords) ? safeSyncData.blacklistKeywords : [];
        whitelistKeywords = Array.isArray(safeSyncData.whitelistKeywords) ? safeSyncData.whitelistKeywords : [];
        mode = safeSyncData.mode || defaultMode;
        
        // Update rules
        setupBlockingRules();
        
        // Clear cache
        blockedUrls.clear();
        
        // Re-evaluate all open tabs if blocking is enabled
        if (isEnabled) {
          logInfo('Re-evaluating all open tabs after sync update');
          checkAllTabs('periodic-sync-update')
            .then(results => {
              logInfo(`Tab re-evaluation complete: checked ${results.checked}, blocked ${results.blocked}`);
            })
            .catch(err => {
              logError('Error during tab re-evaluation:', err);
            });
        }
        
        logInfo('Rules successfully updated from sync storage');
      } catch (innerErr) {
        logError('Error updating rules from sync storage:', innerErr);
      }
    } else {
      logInfo('No changes detected in sync storage');
    }
  } catch (error) {
    logError('Error checking sync status:', error);
  }
}

// Initialize immediately
init();

// Improve the extension's unload handling
chrome.runtime.onSuspend.addListener(() => {
  try {
    logInfo('Extension unloading - restoring blocked tabs');
    
    // Store original state so we don't need to change it in storage
    const originalEnabledState = isEnabled;
    
    // Set to disabled temporarily to use unblocking logic
    isEnabled = false;
    
    // Check all tabs to unblock
    chrome.tabs.query({}).then((tabs) => {
      if (tabs.length > 0) {
        const indexUrl = chrome.runtime.getURL('index.html');
        
        // Use Promise.all for better concurrency
        Promise.all(tabs.map(tab => {
          // Check if this is a blocked page
          if (tab.url && (
              tab.url.includes(`${indexUrl}#blocked?url=`) || 
              tab.url.includes(`${indexUrl}#/blocked?url=`)
            )) {
            try {
              // Extract the original URL that was blocked - handle both formats
              let hash = new URL(tab.url).hash;
              if (hash.startsWith('#/')) {
                hash = hash.substring(2); // Remove the #/ prefix
              } else if (hash.startsWith('#')) {
                hash = hash.substring(1); // Remove the # prefix
              }
              
              const originalUrl = hash.split('url=')[1]?.split('&')[0];
              
              if (originalUrl) {
                const decodedUrl = decodeURIComponent(originalUrl);
                logInfo(`Unblocking tab on unload: ${decodedUrl}`);
                return chrome.tabs.update(tab.id, { url: decodedUrl }).catch(e => {
                  logError(`Failed to unblock tab ${tab.id}:`, e);
                });
              }
            } catch (e) {
              logError('Error extracting URL from blocked page:', e);
            }
          }
          return Promise.resolve(); // Return resolved promise for tabs that don't need unblocking
        })).catch(error => {
          logError('Error during unblock process:', error);
        });
      }
    }).catch(error => {
      logError('Error querying tabs during unload:', error);
    });

    // No need to restore isEnabled state since the service worker is being unloaded
  } catch (error) {
    logError('Error during extension unload handler:', error);
  }
});

// Add a function to safely run debug functions
function safeDebugFunction(fn, ...args) {
  if (ENABLE_DEEP_DEBUGGING) {
    return fn(...args);
  }
  logInfo('Debug function skipped - debugging disabled');
  return null;
}

// Add a more robust setMode function that ensures proper sync
function setMode(newMode) {
  mode = newMode;
  
  // Try to sync first
  chrome.storage.sync.set({ mode }).then(() => {
    logInfo('Mode successfully saved to sync storage');
  }).catch(error => {
    logError('Failed to save mode to sync storage, falling back to local:', error);
    chrome.storage.local.set({ mode }).then(() => {
      logInfo('Mode saved to local storage (fallback)');
    }).catch(localError => {
      logError('Failed to save mode to local storage:', localError);
    });
  });
  
  return true;
}

// Call this function to manually test domain matching in the browser console
// testProblemDomains();

// Utility function for testing URL matching
function testUrlMatch(url, pattern) {
  const regex = wildcardToRegExp(pattern);
  const isMatch = regex.test(url);
  console.log(`Testing URL: ${url} against pattern: ${pattern}`);
  console.log(`Regex: ${regex}`);
  console.log(`Result: ${isMatch ? 'MATCH' : 'NO MATCH'}`);
  
  // Try also with hostname extraction
  try {
    const parsedUrl = new URL(url);
    const hostname = parsedUrl.hostname;
    const hostnameMatch = regex.test(hostname);
    console.log(`Hostname: ${hostname}`);
    console.log(`Hostname match: ${hostnameMatch ? 'MATCH' : 'NO MATCH'}`);
  } catch (e) {
    console.log(`URL parsing failed: ${e.message}`);
  }
  
  return isMatch;
}

// Debug function to test domain matching
function testDomainMatching() {
  console.log("=== TESTING DOMAIN MATCHING ===");
  
  // Test with iptorrents.com
  testUrlMatch("https://iptorrents.com/t", "iptorrents.com");
  testUrlMatch("https://iptorrents.com/t?p=8#torrents", "iptorrents.com");
  testUrlMatch("https://www.iptorrents.com/t", "iptorrents.com");
  
  // Test with wildcards
  testUrlMatch("https://sub.example.com/page", "*.example.com");
  testUrlMatch("https://example.com/page", "*.example.com");
  
  // Test with uppercase/lowercase
  testUrlMatch("https://IPTORRENTS.COM/t", "iptorrents.com");
  
  console.log("=== END TESTING ===");
}